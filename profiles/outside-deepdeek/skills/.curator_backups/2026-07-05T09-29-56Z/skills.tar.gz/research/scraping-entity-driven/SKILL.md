---
name: scraping-entity-driven
description: 实体驱动抓取策略 — 以 person/company/event 为中心，扩展查询后批量搜索+排序+抽取，按时间线聚合
tags:
  - entity-driven
  - person-tracking
  - company-monitoring
  - timeline-aggregation
  - batch-scraping
category: research
---

# 实体驱动抓取 (Entity-Driven)

## 适用场景
以"实体"为中心的舆情/事件追踪（如"马斯克"、"某公司财报"、"美联储"），而非以单个 query 或 URL 为起点。

## 执行流程

```
实体名称 (如 "马斯克")
    │
    ▼
Step 1: 实体扩展
    │  LLM 生成别名/相关关键词
    │  ["马斯克", "Elon Musk", "特斯拉 CEO", "Elon Musk news"]
    ▼
Step 2: 批量搜索
    │  web_search(query="Elon Musk site:reuters.com")
    │  web_search(query="马斯克 site:wsj.com")
    ▼
Step 3: 候选排序
    │  scraping-multi-url-candidate 打分选出每个查询的最佳URL
    ▼
Step 4: 批量抽取
    │  scraping-direct-extract 对每个最佳URL提取正文
    ▼
Step 5: 时间校验
    │  scraping-temporal-validation 检查每个结果
    ▼
Step 6: 按时间线聚合
    │  按 published_at 排序，形成事件时间线
```

## 实体扩展模板
```python
ENTITY_EXPAND_PROMPT = """
给定实体名称，生成用于新闻搜索的扩展查询列表
（包含常见别名、英文名、相关关键词，5个以内）
"""
```

## 适用场景示例
| 实体类型 | 示例 | 扩展查询 |
|---------|------|---------|
| 人物 | 马斯克 | Elon Musk, Tesla CEO, SpaceX, xAI |
| 人物 | 川普 | Donald Trump, President Trump, Trump tariffs, Trump trade |
| 公司 | 美联储 | Federal Reserve, Fed, FOMC, Powell |
| 事件 | 美加贸易谈判 | US-Canada trade, digital tax, CUSMA |

---

## ⚠️ 执行铁律（必须遵守）

### 规则1: 读完后立即执行
读过此 skill 的同一轮响应中，必须**立即发出第一个工具调用**（`web_search`），不得停在描述流程的阶段等待用户确认。违反此规则即 plan→execute 断裂。

### 规则2: 必须跑完整6步
六步流程是**最小完整交付单元**。任何一步都不能跳过或"待后续处理"。完成后必须交付一条按时间线排列的事件报告。

```
❌ 错误: 只做Step 2就停住，问用户"你想深入哪个方向？"
✅ 正确: 6步全部执行完 → 交付时间线报告
```

### 规则3: 不得中途问用户决策
此 skill 是全自动 pipeline，不允许在步骤之间输出选项给用户选择方向。方向选择是 skill 内部做（实体扩展 + 批量搜索覆盖多源），不需要用户介入。

### 规则4: 搜索策略 — 每源独立查询
```python
# ✅ 正确: 每个来源独立搜索
web_search(query="Donald Trump site:reuters.com")
web_search(query="Donald Trump site:apnews.com")
web_search(query="Donald Trump site:wsj.com")

# ❌ 错误: 用 OR 合并到一次查询
web_search(query="site:reuters.com Trump OR site:wsj.com Trump")
```
原因：很多搜索引擎不支持跨站 OR 查询，结果不完整。

### 规则5: 实体不可凭空替换
用户指定的实体（如"川普"）**必须忠于原实体**。不可因为上下文相似而替换成另一个实体（如"马斯克"）。实体替换 = 任务偏差。

---

## 已知失效模式（Pitfalls）

| # | 错误 | 后果 | 修复 |
|:-:|------|------|------|
| 1 | 只读skill不执行 | plan→execute断裂，半成品甩回给用户 | 同一轮发出第一个工具调用 |
| 2 | 做完Step 2就停 | 无时间线 = 未完成 | 必须跑完6步直到交付 |
| 3 | 中途问用户选方向 | pipeline退化为手动流程 | 内部全自动处理 |
| 4 | OR合并搜索 | 结果不完整 | 每来源独立搜索 |
| 5 | 实体被篡改 | 追踪错误的人/公司/事件 | 忠于用户指定的实体 |

---

## 参考文件

- `references/failed-execution-case.md` — 真实失败案例分析：实体驱动执行错误5种模式详解