---
name: web-scraping-pipeline
description: 网页抓取 Pipeline — 10策略调度系统 + V1 时间校验 + 降级链路，适用 WSJ/Reuters/Bloomberg 等付费新闻站
tags:
  - scraping
  - web-scraping
  - pipeline
  - news-extraction
  - wsj
  - reuters
  - bloomberg
  - temporal-validation
  - wayback-machine
  - live-blog
  - multi-source-merge
  - entity-driven
  - paywall-bypass
category: research
---

# Web Scraping Pipeline — 十策略调度系统

## 用户偏好与工作风格

本 skill 遵循以下已固化的工作原则（来自用户反复纠正）：
- **先出方案再执行**：对复杂抓取任务，先输出实施方案（目标URL/策略选择/降级计划），用户确认后再执行
- **优雅优先**：工具优先级 Scrapling > web_extract > 浏览器（用户明确偏好）
- **失败必做根因分析**：抓取失败后必须分析原因（反爬类型/URL错误/时间线问题），建立永久防护机制，而非简单重试
- **V1 硬规则先行**：任何新闻类抓取前，先执行时间校验五条硬规则，不一致则重新搜索而非冒险爬取

## 系统架构

```
用户输入 (URL / query / entity)
        │
        ▼
  ┌─────────────┐
  │   Router    │   ← 意图识别 + 降级链路 + 强制时间校验
  └──────┬──────┘
         │
  ┌──────┴──────┐
  │  策略选择   │
  └──────┬──────┘
         │
  ┌──────┴──────────────────────────────────────────┐
  │  主链路: 04_structured → 07_js_render → 08_archive  │
  │  直播页: 05_live_blog_cards                      │
  │  实体驱动: 10_entity_driven                      │
  └──────┬──────────────────────────────────────────┘
         │
  ┌──────┴──────┐
  │  06_temporal │   ← 强制时间校验（URL年份/发布时间/标题）
  └──────┬──────┘
         │
  ┌──────┴──────┐
  │  09_merge   │   ← 多源融合（可选）
  └─────────────┘
```

## 十策略清单（含精确工具调用）

| # | 策略 | 功能 | 精确工具调用 |
|---|------|------|-------------|
| 01 | **直连抓取** | URL → HTML → 提取正文 | `web_extract(urls=[url])` → 首选；失败后走 Scrapling `StealthyFetcher().fetch(url)` |
| 02 | **搜索→选择→抓取** | query → 搜索 → 选URL → 提取 | `web_search(query=..., limit=5)` → 取第一个非黑名单结果 → `web_extract(urls=[best_url])` |
| 03 | **多候选排序** | 多个候选URL打分 → 选最佳 | `web_search(query=...)` → Python 排序（域名权威度+3/-3, 年份+1/-1, 标题相关度+0.5/词） |
| 04 | **结构化新闻** | HTML → 固定Schema | `web_extract(urls=[url])` → 返回的 Markdown 已含标题/时间/正文 |
| 05 | **直播卡片** | 直播页 → 事件卡片数组 | `web_extract(urls=[live_blog_url])` → 主页面全文；子卡片被DataDome阻断时用 `web_search` 搜索摘要补充 |
| 06 | **时间校验** ⭐ | URL年份/发布时间/标题三方校验 | 纯算法：`extract_years()` 从URL/标题/正文/Last Updated提取，对比5个信号 |
| 07 | **JS渲染** | 动态页面渲染后提取 | `Scrapling StealthyFetcher().fetch(url)` → 依赖 patchright+Chromium |
| 08 | **归档降级** | 原页面失败 → Wayback兜底 | `web_extract(urls=["https://web.archive.org/web/{ts}/{url}"])` |
| 09 | **多源融合** | 多家媒体交叉验证 | `web_search` 多次 → 合并结果 → LLM 提炼共识与分歧 |
| 10 | **实体驱动** | person/company → 批量抓取 | 2+3+4 组合：`web_search`(多查询) → 排序 → `web_extract`(多个URL) |

## 路由决策表

| 输入特征 | 入口策略 | 降级链路 |
|----------|---------|---------|
| 有 `url` + `is_live_blog=True` | **05** 直播卡片 | — |
| 有 `url` | **04** 结构化 → 07 JS渲染 → 08 归档 | 逐级降级 |
| 有 `query` 无 `url` | **03** 排序选URL → **04** 结构化 | → 07 → 08 |
| 有 `entity` | **10** 实体驱动 | 内部复用 03+04 |
| 有 `url` + 已知是付费站 | **04** 结构化 → **08** 归档优先 | 少试 07 |

## 使用方式

### 场景1: 已知URL
```python
# 使用 web_extract 直连
from hermes_tools import web_extract
result = web_extract(urls=["https://www.wsj.com/..."])

# 使用 Scrapling 兜底（当日志未存档）
python scrapling_wsj.py
```

### 场景2: 只有查询意图
```python
from hermes_tools import web_search, web_extract

# Step 1: 搜索
results = web_search(query="美联储利率决议 site:wsj.com")

# Step 2: 候选排序（取权威域名优先+今年优先）
candidates = results["data"]["web"]

# Step 3: 提取
best_url = candidates[0]["url"]
content = web_extract(urls=[best_url])
```

### 场景3: 直播页
```python
from hermes_tools import web_extract
page = web_extract(urls=["https://www.wsj.com/livecoverage/..."])

# 内容已按时间倒序排列的事件卡片
# 每张卡片含 timestamp + title + content
```

## 06 时间校验 V1 五条硬规则（核心防错）

每次新闻提取后**必须**执行此校验。这是防止2025/2026 URL年份混淆等时效性错误的最后防线。

### 规则 ① URL年份优先规则
```
if extract_year_from_url(url) != extract_year_from_content(content):
    flag = HIGH_RISK
    # 如 URL: 06-30-2025, 但内容显示 June 30, 2026
    # → 不得仅凭此 URL 执行爬取
```

### 规则 ② Last Updated 硬约束
```python
last_updated = extract_from_search_snippet("Last Updated: ...")
# 搜索摘要中的 Last Updated 是 TRUSTED SOURCE
# 如果这个字段与 URL 年份不符，说明 URL 指向旧页面/跨年复用的页面
```

### 规则 ③ 多源一致性检查
```python
signals = [
    extract_year_from_url(url),
    extract_year_from_title(title),
    extract_year_from_content(content),
    extract_last_updated_year(search_snippet),
]
year_set = set(filter(None, signals))
if len(year_set) > 1:
    # 存在不一致
    MUST NOT proceed without re-query
    # 重新搜索，找到时间线完全一致的 URL
```

### 规则 ④ Wayback 降级规则
Wayback Machine 是**存档证据源（archival evidence）**，不是**时序真相源（temporal truth source）**。
- 返回的快照可能包含跨年复用的内容（如 WSJ 的 `06-30-2025` URL 包含 2026 年的内容）
- 使用后必须标注 `数据来源: web.archive.org 历史快照`
- 即使内容看起来合理，也要检查快照时间戳是否满足时效性

### 规则 ⑤ 冲突触发机制
**ANY** 不一致出现在以下三个信号之间：
- URL 中的年份
- 标题/描述中的日期
- Last Updated 字段

→ **强制重新搜索**，直到找到时间线完全一致的 URL 后再执行爬取。

### 执行流程
```python
1. 从 URL 路径提取年份（如 06-30-2025 → 2025）
2. 从 web_search 摘要中提取 Last Updated 年份
3. 对比两者
4. 若一致 → confidence="high" → 执行爬取
5. 若不一致 → confidence="low" → 重新搜索最新 URL
6. 爬取成功后，再从正文/标题提取年份做二次校验
```

### 陈旧预警
```python
if published_days_ago > 30 AND expects_breaking_news:
    confidence = "medium"  # 陈旧内容预警，标注时效性不足
```

## 自动化降级链路

当主链路失败时，按以下顺序自动降级：

```
[04] Structured News  →  ❌ 失败
    ↓
[07] JS Render        →  ❌ 反爬拦截
    ↓
[08] Archive Fallback →  ✅ Wayback Machine 有存档 → 成功
    ↓
[06] Temporal Validation → 通过 → 输出 + "数据来源:历史快照" 标注
```

## 参考文件

- `scripts/base.py` — 基础抽象类 (BaseSkill / SkillResult)
- `scripts/router.py` — 调度核心
- `scripts/s01_direct_extract.py` — 直连抓取
- `scripts/s02_search_pick_extract.py` — 搜索选取
- `scripts/s03_multi_url_candidate.py` — 多候选排序
- `scripts/s04_structured_news.py` — 结构化新闻
- `scripts/s05_live_blog_cards.py` — 直播卡片
- `scripts/s06_temporal_validation.py` — 时间校验
- `scripts/s07_js_render.py` — JS渲染
- `scripts/s08_archive_fallback.py` — 归档降级
- `scripts/s09_multi_source_merge.py` — 多源融合
- `scripts/s10_entity_driven.py` — 实体驱动
- `scripts/__init__.py` — 包初始化
- `demo.py` — Mock 测试脚本
- `references/wsj-datadome-patterns.md` — WSJ DataDome 行为记录 + 已验证策略表 + URL年份陷阱案例分析
- `references/rss-system-reference.md` — 已部署的 RSS 扫描系统（98 源数据源，可作为抓取目标的索引）

---

## ⚠️ 执行铁律（全 pipeline 通用）

所有子 skill（s01-s10、scraping-*）以及本 pipeline 本身必须遵守：

### 规则1: 读完后立即执行
读过 skill 的同一轮响应中必须**发出第一个工具调用**。不得停在"我来描述一下流程"阶段。

### 规则2: 必须交付完整结果
pipeline 定义了几步，就必须跑完几步。中间任何一步不能跳过或"后续处理"。最终的交付物必须是可运行的结果（抓取到的内容 / 时间线报告 / 校验结果），不是"这就是我想做的方案"。

### 规则3: 不得中途问用户"你想怎么做"
pipeline 路由决策表已定义了输入→策略的映射关系。用户给出输入后，系统内部决定走哪条路径，不需要用户中途选择方向。把未完成的 pipeline 回退给用户 = 任务未完成。

### 规则4: 工具调用与计划在同一轮
可以写计划，但写计划的同一轮响应中必须紧接着发出工具调用。不允许单独发一个只含计划的响应等用户回复后再执行。
