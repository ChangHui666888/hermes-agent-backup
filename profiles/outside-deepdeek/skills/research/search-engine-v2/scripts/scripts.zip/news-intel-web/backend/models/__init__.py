# Pydantic models
