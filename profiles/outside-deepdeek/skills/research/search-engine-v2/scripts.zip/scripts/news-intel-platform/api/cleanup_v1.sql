-- V1 cleanup: drop old JSON columns after migration verified
-- psql -U news_admin -d news_intel -f cleanup_v1.sql

ALTER TABLE articles DROP COLUMN IF EXISTS source_name;
ALTER TABLE articles DROP COLUMN IF EXISTS source_domain;
ALTER TABLE articles DROP COLUMN IF EXISTS tags;
ALTER TABLE articles DROP COLUMN IF EXISTS entities;
ALTER TABLE articles DROP COLUMN IF EXISTS analysis;
ALTER TABLE articles DROP COLUMN IF EXISTS key_points;

-- Verify
SELECT column_name FROM information_schema.columns WHERE table_name = 'articles' ORDER BY ordinal_position;
