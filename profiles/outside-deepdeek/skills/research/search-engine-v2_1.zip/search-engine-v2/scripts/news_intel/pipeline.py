#!/usr/bin/env python3
"""
news_intel/pipeline.py — 主编排入口

完整流程：
  RSS采集 → 评分 → Intelligence Router → 三级增强 → 存储

用法：
  # 评分 + 增强（不抓全文）
  python -m news_intel.pipeline --hours 2

  # 评分 → 抓全文 → 增强 → 存储
  python -m news_intel.pipeline --hours 2 --fetch

  # 全量跑
  python -m news_intel.pipeline --all --fetch
"""

import sys
import os
import json
import time
import argparse

SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SCRIPT_DIR)

from news_intel.db import init_db, get_db, upsert_content
from news_intel.scorer import score_article, compute_velocity
from news_intel.router import route
from news_intel.sync import sync_recent


def run_pipeline(hours: int = 2, limit: int = 200, do_fetch: bool = False):
    """
    运行完整流水线。

    Args:
        hours: 处理最近N小时的RSS数据
        limit: 最大处理篇数
        do_fetch: 是否调用 batch.py 抓取全文
    """
    start = time.monotonic()

    # 1. 初始化数据库
    init_db()
    db = get_db()

    # 2. 同步 + 评分
    stats = sync_recent(hours=hours, limit=limit)
    if not stats:
        db.close()
        return

    # 3. 为 Tier A/B 文章做增强
    rows = db.execute("""
        SELECT ni.id as intel_id, ni.tier, ni.score_total,
               rr.title, rr.description, rr.article_url, rr.source_name
        FROM news_intelligence ni
        JOIN rss_raw rr ON ni.raw_id = rr.id
        WHERE ni.tier IN ('A', 'B')
        ORDER BY ni.score_total DESC
        LIMIT ?
    """, (limit,)).fetchall()

    print(f"\n[pipeline] 增强 {len(rows)} 篇 Tier A/B 文章...")

    # 提取待抓取 URL
    urls_to_fetch = [(row["article_url"], row["intel_id"], row["tier"])
                     for row in rows if row["article_url"]]

    # 如果有正文抓取需求且 do_fetch，调用 batch.py
    fetched_content = {}
    if do_fetch and urls_to_fetch:
        import tempfile
        import subprocess
        batch_script = os.path.join(SCRIPT_DIR, "batch.py")
        if os.path.exists(batch_script):
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as tf:
                tf.write("\n".join(url for url, _, _ in urls_to_fetch))
                url_file = tf.name
            out_file = os.path.join(os.path.dirname(__file__), "_fetch_tmp.jsonl")
            print(f"  [fetch] 抓取 {len(urls_to_fetch)} 篇全文...")
            subprocess.run([
                sys.executable, batch_script,
                "--urls", url_file, "--out", out_file,
                "--rate-delay", "0.5", "--max-workers", "3", "--no-progress",
            ], cwd=SCRIPT_DIR, timeout=300)
            # 读取抓取结果
            if os.path.exists(out_file):
                with open(out_file, encoding="utf-8") as f:
                    for line in f:
                        data = json.loads(line)
                        if data.get("ok"):
                            fetched_content[data["url"]] = data.get("content", "")
                os.remove(out_file)
            os.unlink(url_file)

    enhanced = 0
    for row in rows:
        intel = db.execute(
            "SELECT entities, tags FROM news_intelligence WHERE id=?",
            (row["intel_id"],)
        ).fetchone()
        entities = json.loads(intel["entities"]) if intel and intel["entities"] else {}
        tags = json.loads(intel["tags"]) if intel and intel["tags"] else []

        # 获取正文
        content_md = fetched_content.get(row["article_url"], "")

        result = route(
            title=row["title"] or "",
            description=row["description"] or "",
            scores={"tier": row["tier"], "entities": entities, "categories": tags},
            content_md=content_md,
        )

        # 写入 content 层
        upsert_content(db, row["intel_id"], {
            "article_url": row["article_url"],
            "content_md": content_md,
            "content_len": len(content_md),
            "summary_cn": result.get("summary_cn", ""),
            "summary_en": result.get("summary_en", ""),
            "extraction_method": result.get("method", "unknown"),
            "llm_model": result.get("llm_model"),
            "llm_cost": result.get("llm_cost", 0.0),
            "source_headline": row["title"],
        })
        enhanced += 1

    elapsed = time.monotonic() - start

    # 统计
    tier_counts = {"A": 0, "B": 0, "C": 0}
    tc = db.execute("SELECT tier, COUNT(*) as cnt FROM news_intelligence WHERE scored_at > datetime('now', ? || ' hours', 'localtime') GROUP BY tier", (f"-{hours}",)).fetchall()
    for t in tc:
        tier_counts[t["tier"]] = t["cnt"]

    db.close()

    print(f"\n{'='*60}")
    print(f"Pipeline 完成 | 耗时: {elapsed:.1f}s")
    print(f"  Tier A (>90):    {tier_counts['A']:>4}篇 → DeepSeek V4 Flash")
    print(f"  Tier B (60-90):  {tier_counts['B']:>4}篇 → Qwen3-1.7B 本地")
    print(f"  Tier C (<60):    {tier_counts['C']:>4}篇 → Python 规则（零成本）")
    print(f"  增强处理:         {enhanced:>4}篇")
    print(f"  总成本:           ${sum(r.get('llm_cost', 0) for r in []) * enhanced:.4f}")
    print(f"{'='*60}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="News Intelligence Pipeline")
    parser.add_argument("--hours", type=int, default=2, help="处理最近N小时 (default: 2)")
    parser.add_argument("--limit", type=int, default=200, help="最大篇数 (default: 200)")
    parser.add_argument("--fetch", action="store_true", help="抓取全文（调用 batch.py）")
    parser.add_argument("--all", action="store_true", help="全量处理")
    args = parser.parse_args()

    h = 720 if args.all else args.hours
    run_pipeline(hours=h, limit=args.limit, do_fetch=args.fetch)
