# News Intelligence Engine — 评分·路由·增强

> 子系统路径: `scripts/news_intel/`

## 架构

```
RSS (rss-archive.db)
     │
     ▼  sync.py
news_intel.db (三表: rss_raw / news_intelligence / news_content)
     │
     ▼  scorer.py
五维评分 (0-100, 每维度硬上限)
     │
     ├─ Tier A (≥85) → DeepSeek V4 Flash 深度分析
     ├─ Tier B (60-84) → Qwen3-1.7B 本地增强
     └─ Tier C (<60)  → Python 规则（零成本）
```

## 五维评分

| 维度 | 满分 | 上限保护 | 数据来源 |
|------|:--:|------|------|
| Source Authority | 20 | 配置 JSON 最高值 | `source_scores.json` |
| Event Impact | 30 | `min(score, 30)`, 同类取最高 | `event_keywords.json` |
| Entity Importance | 20 | `min(score, 20)` | `entity_weights.json` |
| Market Relevance | 20 | `min(score, 20)` | `asset_graph.json` |
| Velocity | 10 | `if >= 10: return 10` | 标题指纹 + Jaccard 0.5 |
| **Total** | **100** | `min(total, 100)` | |

### Velocity 计算（Jaccard 相似度）

```python
# 指纹生成：标题前8个实词（去停用词）
fp = set(meaningful_words[:8])

# 两篇同事件判定：Jaccard ≥ 0.5 且 发布时间差 ≤ 30min
intersection = len(fp_a & fp_b)
union = len(fp_a | fp_b)
if intersection / union >= 0.5 and abs(ts_a - ts_b) <= 30min:
    count += 1
```

**Pitfall**: RSS 日期格式多样（`Wed, 08 Jul 2026` / `2026-07-08T14:00:00Z`），需 `email.utils.parsedate_to_datetime` 兼容解析。

## 实测分布 (60篇, 2026-07-08)

```
Tier A (≥85):  1篇 (1.7%) → DeepSeek
Tier B (60-84): 6篇 (10.0%) → Qwen3
Tier C (<60):  53篇 (88.3%) → Python
```

## 三层增强器

### Tier C: `enhance_python()` — 零成本
- 标签: 关键词映射 (`tag_map`)
- 实体: 配置匹配 + ticker 正则
- 摘要: 前2句规则截取

### Tier B: `enhance_qwen()` — Qwen3-1.7B
- 端点: `http://127.0.0.1:1234/v1/chat/completions`
- 模型: `qwen3-1.7b-instruct`
- 超时: 5秒（不可用时自动降级 Python）
- 任务: 标签增强 + 实体抽取 + 一句话摘要

### Tier A: `enhance_deepseek()` — DeepSeek V4 Flash
- 需要 `DEEPSEEK_API_KEY` 环境变量
- 输入: 标题 + 摘要 + 前8段正文（≤3000字符）
- 输出: `{event, impact, companies, assets, market_signal, risk_level, future_watch, confidence}`

## 配置文件

| 文件 | 内容 |
|------|------|
| `config/source_scores.json` | 70+ 来源权威度 (0-20) |
| `config/event_keywords.json` | 5领域事件关键词 (0-30) |
| `config/entity_weights.json` | 公司/人物/国家权重 (0-20) |
| `config/asset_graph.json` | 20+ 资产链 (新闻→股票映射) |

## 命令

```bash
# 评分 + 增强
python -m news_intel.pipeline --hours 2

# 评分 + 抓全文 + 增强
python -m news_intel.pipeline --hours 2 --fetch

# 仅同步评分
python -m news_intel.sync --hours 2
```
