---
name: search-engine-v2
description: 搜索抓取引擎v2 — 域名画像知识库 + 成本感知级联引擎 + 多源融合 + 实体追踪。优先走脚本逻辑执行，保证质量和可观测性。
tags:
  - search
  - scraping
  - web-scraping
  - domain-profile
  - cascade
  - temporal-validation
  - multi-source-merge
  - entity-driven
  - cost-trace
  - wsj
  - paywall-bypass
  - newsweek
  - aljazeera
  - bbc
  - nyt
  - guardian
category: research
---

# 搜索抓取引擎 v2（重构版）

## 核心架构

```
用户输入 (URL / query / entity)
        │
        ▼
  ┌─────────────┐
  │   Router    │   ← 意图识别 + 域名画像查表 + 自动路由
  └──────┬──────┘
         │
  ┌──────┴──────────────────────────────────────┐
  │  有 entity → EntityTrackSkill               │
  │  有 query  → discover → rank → extract      │
  │  有 url                                     │
  │    ├─ wsj.com  → WSJSkill（DataDome知情规避）│
  │    └─ 其他     → ExtractSkill（域名画像梯度） │
  │   [A级/require_cross_check]                 │
  │    └─ 自动触发 ParallelExtract + Merge       │
  └──────┬──────────────────────────────────────┘
         │
  ┌──────┴──────┐
  │  全局时间校验 │   ← temporal.py (freshness_mode感知)
  └─────────────┘
         │
  ┌──────┴──────┐
  │ cost_trace  │   ← 每个策略的成本记录，用于监控调优
  └─────────────┘
```

## 关键改进（vs v1）

| 改进 | 说明 |
|------|------|
| **域名画像知识库** | domain_profiles.py — 每个域名预配置反爬级别、最优策略顺序、已知必败工具 |
| **成本感知级联** | cascade.py — 先查画像 → 剪枝必败工具 → 逐级尝试成功即停 |
| **可观测性** | 每次调用返回 `cost_trace` + `total_cost` |
| **并行抓取** | s05_parallel — delegate_task 多URL并行 |
| **多源融合** | s06_merge — LLM 交叉验证共识/分歧 |
| **时间校验 v2** | temporal.py — freshness_mode 感知（breaking/market/analysis/default） |
| **WSJ 时间戳修复** | s04_wsj.py 正则支持 MM-DD-YYYY 格式（live blog URL 如 06-30-2025） |

## 域名画像表（已收录 16 个域名）

| 域名 | 反爬级别 | 策略顺序 | 已知必败 |
|------|---------|---------|---------|
| wsj.com | datadome | direct → archive → search_snippet | scrapling, browser |
| bloomberg.com | datadome | direct → archive → search_snippet | scrapling, browser |
| ft.com | datadome | direct → archive → search_snippet | scrapling, browser |
| nytimes.com | soft_paywall | direct → archive → search_snippet | — |
| washingtonpost.com | soft_paywall | direct → archive → search_snippet | — |
| cnbc.com | cloudflare | direct → scrapling → archive → search_snippet | — |
| businessinsider.com | cloudflare | direct → scrapling → archive → search_snippet | — |
| reuters.com | none | direct | — |
| apnews.com | none | direct | — |
| newsweek.com | none | direct → archive → search_snippet | — |
| aljazeera.com | none | direct | — |
| theguardian.com | none | direct | — |
| bbc.com | none | direct | — |
| cnn.com | none | direct | — |
| arxiv.org | none | direct | — |
| 未知域名 | unknown | 全梯度: direct→archive→scrapling→browser→computer→snippet | — |

## 策略梯度成本图

```
策略         成本    Hermes 工具映射
────────────────────────────────────
direct        1     web_extract(url)
archive       1     web_extract(archive.org)
search_snippet 1    web_search(url) → 取第一条摘要
scrapling     2     (当前不可用，execute_code bug)
browser       3     browser_navigate (Playwright)
computer_use  5     computer_use (桌面驱动，终极兜底)
```

## ⚠️ 已知问题与规避

### execute_code 不可用
Hermes v0.17.0 中 `execute_code` 因中间件包装函数参数不匹配而报错。替代方案：
- **算法逻辑**（时间校验/候选排序）→ `terminal` + Python 调用 `core/temporal.py` 或 `skills/s02_rank.py`
- **搜索/提取** → 直接用 Hermes 工具 `web_search` / `web_extract`
- 写计划可以，但**同一轮必须发出第一个工具调用**，不得停在计划阶段

### WSJ 时间戳格式
首次测试发现 `s04_wsj.py` 的 `WSJ_DATE_RE` 只匹配 `/YYYY/MM/DD/` 格式，遗漏了 `06-30-2025` 格式的 live blog URL。修复：新增 `WSJ_DATE_ALT_RE` 正则。通用 temporal.py 引擎不受此限制。

## 2026-07-01 全场景实测结果

| 场景 | 域名 | cascade 路径 | cost | 状态 |
|:----:|------|------------|:----:|:----:|
| WSJ文章 → archive | wsj.com | direct❌→archive✅ | 1 | ✅ |
| WSJ Live Blog 直连 | wsj.com | direct✅ | 1 | ✅ |
| query驱动 → Reuters | reuters.com | direct✅ | 1 | ✅ |
| Reuters直连 | reuters.com | direct✅ | 1 | ✅ |
| 实体追踪 Trump | 多源 | search→rank→extract | 1 | ✅ |
| Newsweek直连 | newsweek.com | direct✅ | 1 | ✅ |

## 调用方式

### 方式 A：由 Agent 按 SKILL.md 流程手动调用工具（推荐，当前可用）

```
# 场景1: 已知 URL
web_extract(urls=["https://www.reuters.com/..."])  # 一级提取
→ 失败则 web_extract(urls=["https://web.archive.org/web/{url}"])  # 二级降级
→ 失败则 web_search(query="site:wsj.com article title")  # 三级搜索摘要

# 场景2: 只有查询
web_search(query="美联储利率 2026 site:reuters.com")  # 搜索
→ 候选打分排序（按域名权威度+年份+相关度）
→ web_extract(best_url)  # 提取

# 场景3: 时间校验
# 每次提取后检查 URL年份、标题年份、发布年份是否一致
```

### 方式 B：直接调用 Python 脚本（纯算法逻辑可用）

```bash
cd scripts/
python -c "
from skills.s02_rank import score_candidate
score = score_candidate({'url':'...', 'title':'...'}, query='美联储', current_year=2026)
"
```

## 参考文件

- `scripts/config/domain_profiles.py` — 域名画像知识库（16个域名）
- `scripts/core/base.py` — HermesToolbox + BaseSkill 基础抽象
- `scripts/core/cascade.py` — 成本感知级联引擎
- `scripts/core/temporal.py` — 时间一致性校验
- `scripts/skills/__init__.py` — 所有 Skill 导出
- `scripts/skills/s01_discover.py` — 三级搜索发现
- `scripts/skills/s02_rank.py` — 多维度候选排序
- `scripts/skills/s03_extract.py` — 内容提取（级联 + 时间校验 + LLM结构化）
- `scripts/skills/s04_wsj.py` — WSJ 专用（DataDome知情规避 + 修复版时间戳正则）
- `scripts/skills/s05_parallel.py` — 并行批量抓取
- `scripts/skills/s06_merge.py` — 多源融合
- `scripts/skills/s07_entity.py` — 实体驱动追踪
- `scripts/router.py` — 总调度器
- `scripts/demo.py` — 8场景 Mock 演示
